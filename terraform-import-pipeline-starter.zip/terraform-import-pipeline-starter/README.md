# GitLab Terraform Import Pipeline for AWS

This starter implements a safe adoption workflow for existing AWS resources. It is designed for commercial AWS and GovCloud, GitLab OIDC, an S3 backend, and Terraform 1.5 or newer. The sample pins Terraform `1.13.2` and AWS provider `6.28.0`; change both only through a normal reviewed dependency update.

The key design decision is that imports happen in the repository and state that will own the resource permanently. There is no temporary import repository and no copying of state. Terraform `import` blocks are the normal path. The imperative `terraform import` command is reserved for documented recovery cases.

## 1. Architecture and workflow

```mermaid
flowchart TD
    A["Inventory existing resource"] --> B["Choose permanent state and address"]
    B --> C{"Canonical HCL known?"}
    C -- No --> D["Read-only generate job"]
    D --> E["Engineer cleans generated HCL"]
    C -- Yes --> F["MR: resource + import block + manifest"]
    E --> F
    F --> G["Validate and preflight"]
    G --> H["Import-only plan policy"]
    H --> I["MR approval and merge"]
    I --> J["Protected manual import apply"]
    J --> K["Automatic zero-change plan"]
    K --> L["Cleanup MR removes import files"]
```

The adoption is deliberately split from later remediation. If the existing resource needs new tags, encryption, rule changes, an AMI replacement, or any other mutation, import it as-is first. Make the change in a second MR through the standard Terraform pipeline. That separation gives reviewers a clear answer to the most important question: "Will this import touch the live resource?"

### Pipeline stages

| Stage | Job | Credentials | State or AWS effect |
| --- | --- | --- | --- |
| `validate` | `tf_import_validate` | None | Format, manifest, lockfile, and Terraform validation only |
| `generate` | `tf_import_generate_config` | Plan role | Optional read-only HCL generation; never applies |
| `preflight` | `tf_import_preflight` | Plan role | Confirms account, partition, Region, backend protections, state address availability |
| `plan` | `tf_import_plan` | Plan role | Produces saved plan and rejects every infrastructure mutation |
| `import` | `tf_import_apply` | Import role | Protected/manual; writes state only from the reviewed saved plan |
| `verify` | `tf_import_verify` | Plan role | Must return a zero-change plan after import |

### Trust boundaries

- `AWS_PLAN_ROLE_ARN`: target-resource read permissions; S3 state read; DynamoDB lock access.
- `AWS_IMPORT_ROLE_ARN`: target-resource read permissions; S3 state read/write; DynamoDB lock access. It must not have resource mutation permissions.
- Your normal Terraform apply role is separate and is not used by this pipeline.
- GitLab OIDC replaces static AWS access keys. The plan role can trust approved branches/MR pipelines; the import role should trust only the default protected branch.
- `resource_group` serializes import jobs for the same stack, while Terraform's backend lock protects state writes.
- The S3 state bucket must have versioning, default encryption, and Block Public Access enabled.

The import role's lack of AWS write permissions is intentional defense in depth. Even if a policy script were changed incorrectly, a plan that attempts to update the resource should fail at AWS authorization.

## 2. Repository and implementation

```text
.
├── .gitlab-ci.yml
├── ci/
│   ├── Dockerfile
│   └── terraform-import.gitlab-ci.yml
├── scripts/
│   ├── ci-common.sh
│   ├── validate_manifest.py
│   ├── check_import_plan.py
│   ├── validate.sh
│   ├── generate-config.sh
│   ├── preflight.sh
│   ├── plan-import.sh
│   ├── apply-import.sh
│   └── verify-import.sh
├── envs/
│   └── dev/
│       ├── backend.tf
│       ├── versions.tf
│       ├── providers.tf
│       ├── variables.tf
│       ├── resources.tf
│       ├── imports.tf
│       ├── terraform.tfvars.example
│       └── import-manifest.json
├── iam/
│   ├── gitlab-oidc-trust-main.json
│   ├── state-plan-policy.json
│   ├── state-import-policy.json
│   └── target-read-s3-example.json
└── tests/
    ├── test_plan_policy.py
    └── fixtures/
```

For a monorepo, create one root directory per independently locked state, for example:

```text
envs/
├── commercial/717512776491/us-east-1/network/
├── govcloud/nonprod/us-gov-west-1/app-a/
└── govcloud/prod/us-gov-west-1/app-a/
```

Do not derive a permanent state key from `CI_COMMIT_BRANCH`. A feature branch must plan against the same permanent state that the default branch owns. The sample builds a stable key from the project path and `TF_STACK`, such as `tfstate/group-project/commercial-dev-us-east-1-network/terraform.tfstate`.

### Required GitLab CI/CD variables

Set these at the group level where possible, then environment-scope the account-specific values.

| Variable | Example | Notes |
| --- | --- | --- |
| `TF_CI_IMAGE` | `registry.example.com/platform/terraform-aws:1.13.2` | Build from `ci/Dockerfile`; pin by digest in production |
| `GITLAB_OIDC_AUDIENCE` | `https://gitlab.com` | Must match the AWS OIDC provider/client ID |
| `AWS_PLAN_ROLE_ARN` | `arn:aws:iam::123456789012:role/gitlab-terraform-plan` | Read-only target role |
| `AWS_IMPORT_ROLE_ARN` | `arn:aws:iam::123456789012:role/gitlab-terraform-import` | State-write, target-read-only role |
| `TF_STATE_BUCKET` | `terraformstate717512776491` | Use the correct commercial or GovCloud state bucket |
| `TF_STATE_REGION` | `us-east-1` | Region containing the state bucket |
| `TF_LOCK_TABLE` | `terraform-state-lock` | Existing DynamoDB lock table |
| `TF_STATE_KMS_KEY_ID` | KMS key ARN | Optional in sample; recommended for enterprise state |
| `TF_REQUIRE_KMS_STATE` | `true` | Set true after KMS state encryption is confirmed |

The sample `.gitlab-ci.yml` holds stack-specific nonsecret values: `TF_ROOT`, `TF_STACK`, expected account, partition, and Region. Keep the AWS role ARNs and backend configuration in protected CI/CD variables.

The IAM JSON files use commercial `arn:aws` examples. For GovCloud, replace every partition-qualified ARN with `arn:aws-us-gov` and use the correct GovCloud account and Region before creating policies.

### Manifest and configuration contract

`import-manifest.json` is a machine-checked change record. Every expected import address and ID must be declared there. The Terraform plan JSON must contain exactly those imports, with no managed-resource actions other than `no-op`.

The example imports an S3 bucket and its public-access-block resource. Replace it with the actual resource blocks and provider-specific import IDs. Complex AWS objects often require multiple Terraform resources. Examples include security groups plus individual rule resources, an EC2 instance plus ENIs/EBS attachments, and an S3 bucket plus versioning/encryption/public-access resources.

If the resource HCL is unknown, set `TF_IMPORT_GENERATE` to `true` for a pipeline. Only the generation job runs. Download `generated_resources.tf`, review it, remove computed-only and redundant arguments, split child resources correctly, and commit canonical HCL. Then run the controlled mode with `TF_IMPORT_GENERATE=false`.

Generated configuration is a starting point, not production-ready code. The pipeline never applies it automatically.

## 3. Operating runbook and controls

### First-time setup

1. Build and publish `ci/Dockerfile` to your internal registry. Pin `TF_CI_IMAGE` to an immutable digest after validation.
2. Create the GitLab OIDC provider and separate plan/import roles in each AWS account or provision them centrally with your organization bootstrap process.
3. Configure the protected CI/CD variables. Never paste tokens or AWS credentials into manual job variables.
4. Replace the sample environment data and resource blocks.
5. Run `terraform init` with the permanent backend, confirm the provider selection, and commit `.terraform.lock.hcl`.
6. Protect the default branch and the `terraform-import/*` environment. Restrict Allowed to Deploy to the Terraform operator group. If your GitLab tier supports deployment approvals, require a second approver for production.

### Per-import procedure

1. Inventory the resource, its dependencies, import ID, owning repository, permanent resource address, and permanent state key.
2. Create an import branch and add the canonical resource HCL, `imports.tf`, and `import-manifest.json` with a change/ticket ID.
3. If needed, run generation mode first. Do not proceed with unreviewed generated HCL.
4. Open an MR. The plan must show imports only. Any `create`, `update`, `delete`, or replacement fails policy.
5. Obtain the normal code-owner/MR approvals and merge to the protected default branch.
6. Review the default-branch plan artifact, then run the protected `tf_import_apply` manual job. It applies the exact saved plan from the same commit.
7. The verification job must return exit code `0` and report no changes.
8. Open a cleanup MR that removes `imports.tf` and `import-manifest.json`. Git history and the change ticket remain the audit record.
9. Make intentional remediations in separate MRs using the normal Terraform plan/apply pipeline.

### Mandatory safety checks

- Expected AWS account ID, ARN partition (`aws` or `aws-us-gov`), and Region must match both CI configuration and the manifest.
- `TF_ROOT` and the stable state key must match the permanent owning stack.
- The resource address must not already exist in state.
- `.terraform.lock.hcl` must exist and remain committed.
- State bucket versioning, encryption, and Block Public Access must pass.
- State locking is always enabled. The scripts never use `-lock=false` or automated `force-unlock`.
- A saved binary plan from the same commit is required for the import job.
- Plan policy requires the exact manifest import set and rejects all live-resource mutations.
- Apply is manual, blocking, protected, confirmation-gated, and serialized by state stack.
- Plan and state-related artifacts are restricted to Maintainers and expire after 24 hours because plan files can contain sensitive values.
- The post-import plan must be completely empty.

### Failure and rollback rules

- Before apply: fix HCL until the plan is import-only. Do not weaken the plan policy.
- Import apply fails before state write: correct the permission or lock issue and create a fresh plan. Do not reuse a stale plan.
- Import succeeds but verification shows drift: do not run a normal apply. Correct the HCL to match reality and re-plan.
- Wrong address but correct physical resource: use reviewed `moved` blocks or a controlled `terraform state mv`; do not re-import the same object to a second address.
- Incorrect state write: halt pipelines, inspect the S3 object versions and Terraform state lineage/serial, and restore only through a peer-reviewed break-glass procedure. State restoration is intentionally not automated here.
- Never use `terraform state rm` merely to make a plan green. Removing state does not change the live resource and can cause Terraform to create a duplicate later.

For the Windows 2019-to-2022 project, use this process to adopt stable supporting infrastructure first. Keep the OS migration as a separate lifecycle project; importing an EC2 instance does not make in-place operating-system replacement safe, and private-IP retention should be designed around the ENI rather than hidden inside an import step.

### Authoritative references

- [Terraform import workflow](https://developer.hashicorp.com/terraform/language/import/single-resource)
- [Terraform generated configuration](https://developer.hashicorp.com/terraform/language/import/generating-configuration)
- [Terraform plan options and detailed exit codes](https://developer.hashicorp.com/terraform/cli/commands/plan)
- [Terraform state locking](https://developer.hashicorp.com/terraform/language/state/locking)
- [GitLab OIDC with AWS](https://docs.gitlab.com/ci/cloud_services/aws/)
- [GitLab resource groups](https://docs.gitlab.com/ci/resource_groups/)
- [GitLab protected environments](https://docs.gitlab.com/ci/environments/protected_environments/)
- [GitLab manual job controls](https://docs.gitlab.com/ci/jobs/job_control/)
