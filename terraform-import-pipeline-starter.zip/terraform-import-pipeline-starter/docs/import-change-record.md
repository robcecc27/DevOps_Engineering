# Terraform Import Change Record

Use one copy of this record per import batch and link it from the change ticket or merge request.

## Scope

- Change/ticket ID:
- Owning team:
- Repository and MR:
- AWS partition/account/Region:
- Terraform root and permanent state key:
- Business/service owner:
- Maintenance or change window, if required:

| Terraform address | AWS resource type | Import ID | Dependencies included | Criticality |
| --- | --- | --- | --- | --- |
|  |  |  |  |  |

## Review evidence

- [ ] Resource ownership and permanent state were confirmed.
- [ ] Existing state does not already contain the addresses.
- [ ] Every dependent Terraform resource was identified.
- [ ] Generated HCL, if used, was manually normalized.
- [ ] Provider and Terraform versions are locked.
- [ ] Plan contains the exact manifest imports.
- [ ] Plan contains no create, update, replace, or delete actions.
- [ ] State bucket protections and locking passed.
- [ ] MR/code-owner approval completed.
- [ ] Protected import job approval completed.

## Outcome

- Import pipeline URL:
- Import operator:
- Import completion time:
- Pre-import state lineage/serial:
- Post-import state lineage/serial:
- Zero-change verification pipeline URL:
- Cleanup MR:
- Follow-up remediation MRs:
- Exceptions or notes:
