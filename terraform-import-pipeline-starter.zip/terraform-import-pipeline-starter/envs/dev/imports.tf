# Delete this file in a cleanup MR after the import and zero-change verification.
import {
  to = aws_s3_bucket.existing_logs
  id = "replace-me-existing-bucket"
}

import {
  to = aws_s3_bucket_public_access_block.existing_logs
  id = "replace-me-existing-bucket"
}

