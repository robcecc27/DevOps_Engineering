provider "aws" {
  region = var.aws_region

  # CI already obtains the correct role through GitLab OIDC. Do not add an
  # assume_role block that tries to assume the same role a second time.
}

