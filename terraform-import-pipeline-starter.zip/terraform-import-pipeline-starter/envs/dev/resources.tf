resource "aws_s3_bucket" "existing_logs" {
  bucket = var.existing_bucket_name

  lifecycle {
    prevent_destroy = true
  }
}

resource "aws_s3_bucket_public_access_block" "existing_logs" {
  bucket = aws_s3_bucket.existing_logs.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true

  lifecycle {
    prevent_destroy = true
  }
}

