variable "aws_region" {
  description = "AWS Region that owns the imported resources."
  type        = string
}

variable "existing_bucket_name" {
  description = "Name of the existing S3 bucket being adopted."
  type        = string
}

