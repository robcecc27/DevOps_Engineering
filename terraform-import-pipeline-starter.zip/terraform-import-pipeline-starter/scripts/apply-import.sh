#!/usr/bin/env bash

set -Eeuo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/ci-common.sh"

[[ "${CI_COMMIT_BRANCH:-}" == "${CI_DEFAULT_BRANCH:-}" ]] || fail "Import apply is permitted only on the default branch"
[[ -n "${AWS_PLAN_ROLE_ARN:-}" && -n "${AWS_IMPORT_ROLE_ARN:-}" ]] || fail "Plan and import roles must both be configured"
[[ "$AWS_PLAN_ROLE_ARN" != "$AWS_IMPORT_ROLE_ARN" ]] || fail "Plan and import must use separate IAM roles"

plan_file="${ARTIFACT_DIR}/import.tfplan"
plan_json="${ARTIFACT_DIR}/import-plan.json"
metadata="${ARTIFACT_DIR}/plan-metadata.json"
[[ -s "$plan_file" && -s "$plan_json" && -s "$metadata" ]] || fail "Required reviewed plan artifacts are missing"

validate_manifest
python3 "${PROJECT_DIR}/scripts/check_import_plan.py" \
  --manifest "$MANIFEST_FILE" \
  --plan-json "$plan_json"

python3 - "$metadata" "$MANIFEST_FILE" "$plan_file" <<'PY'
import hashlib
import json
import os
import sys

metadata_path, manifest_path, plan_path = sys.argv[1:]

def digest(path: str) -> str:
    value = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()

with open(metadata_path, encoding="utf-8") as handle:
    metadata = json.load(handle)
expected_commit = os.environ.get("CI_COMMIT_SHA", "local")
checks = {
    "commit_sha": expected_commit,
    "manifest_sha256": digest(manifest_path),
    "plan_sha256": digest(plan_path),
}
for key, expected in checks.items():
    if metadata.get(key) != expected:
        print(f"[terraform-import] ERROR: plan metadata mismatch for {key}", file=sys.stderr)
        raise SystemExit(1)
PY

configure_aws_oidc AWS_IMPORT_ROLE_ARN
verify_aws_target
terraform_init
verify_state_bucket_controls

current_metadata="$(mktemp)"
capture_state_metadata "$current_metadata"
python3 - "$metadata" "$current_metadata" <<'PY'
import json
import sys

with open(sys.argv[1], encoding="utf-8") as handle:
    planned = json.load(handle)
with open(sys.argv[2], encoding="utf-8") as handle:
    current = json.load(handle)
for key in ("lineage", "serial", "state_key"):
    if planned.get(key) != current.get(key):
        print(f"[terraform-import] ERROR: state {key} changed after the plan was created", file=sys.stderr)
        raise SystemExit(1)
PY
rm -f "$current_metadata"

set +e
terraform -chdir="$TF_DIR" apply \
  -auto-approve \
  -input=false \
  -lock-timeout=5m \
  "$plan_file" 2>&1 | tee "${ARTIFACT_DIR}/import-apply.log"
apply_rc=${PIPESTATUS[0]}
set -e
(( apply_rc == 0 )) || fail "Terraform import apply failed with exit code ${apply_rc}"

post_addresses="${ARTIFACT_DIR}/post-import-addresses.txt"
list_state_addresses "$post_addresses"
assert_addresses_present_in_state "$post_addresses"
capture_state_metadata "${ARTIFACT_DIR}/post-import-metadata.json"

log "Import completed and all manifest addresses are present in state"
