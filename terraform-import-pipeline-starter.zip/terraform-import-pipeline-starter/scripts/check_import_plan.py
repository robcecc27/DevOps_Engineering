#!/usr/bin/env python3

import argparse
import json
import sys
from pathlib import Path


def fail(messages: list[str]) -> None:
    for message in messages:
        print(f"[terraform-import] POLICY DENY: {message}", file=sys.stderr)
    raise SystemExit(1)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--plan-json", required=True)
    args = parser.parse_args()

    manifest = json.loads(Path(args.manifest).read_text(encoding="utf-8"))
    plan = json.loads(Path(args.plan_json).read_text(encoding="utf-8"))

    expected = {item["address"]: str(item["import_id"]) for item in manifest["resources"]}
    observed: dict[str, str | None] = {}
    violations: list[str] = []

    for change in plan.get("resource_changes", []):
        address = change.get("address", "<unknown>")
        mode = change.get("mode", "managed")
        detail = change.get("change", {})
        actions = detail.get("actions", [])
        importing = detail.get("importing")

        if mode == "data":
            if actions not in (["read"], ["no-op"]):
                violations.append(f"data resource {address} has unexpected actions {actions}")
            continue

        if actions != ["no-op"]:
            violations.append(f"managed resource {address} has forbidden actions {actions}")

        if importing is not None:
            import_id = importing.get("id") if isinstance(importing, dict) else None
            observed[address] = None if import_id is None else str(import_id)

    missing = sorted(set(expected) - set(observed))
    extra = sorted(set(observed) - set(expected))
    if missing:
        violations.append(f"manifest imports missing from plan: {', '.join(missing)}")
    if extra:
        violations.append(f"plan imports not declared in manifest: {', '.join(extra)}")

    for address in sorted(set(expected) & set(observed)):
        if observed[address] is not None and observed[address] != expected[address]:
            violations.append(
                f"import ID mismatch for {address}: plan={observed[address]!r} manifest={expected[address]!r}"
            )

    if violations:
        fail(violations)

    print(f"[terraform-import] POLICY ALLOW: exactly {len(observed)} import(s), no infrastructure mutations")


if __name__ == "__main__":
    main()
