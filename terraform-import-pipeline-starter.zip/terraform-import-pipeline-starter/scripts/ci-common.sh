#!/usr/bin/env bash

set -Eeuo pipefail

PROJECT_DIR="${CI_PROJECT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
TF_ROOT="${TF_ROOT:-envs/dev}"
TF_DIR="${PROJECT_DIR}/${TF_ROOT}"
MANIFEST_FILE="${TF_DIR}/import-manifest.json"
ARTIFACT_DIR="${PROJECT_DIR}/artifacts"
AWS_TOKEN_FILE="${PROJECT_DIR}/.gitlab-oidc-token"

mkdir -p "$ARTIFACT_DIR"

log() {
  printf '[terraform-import] %s\n' "$*"
}

fail() {
  printf '[terraform-import] ERROR: %s\n' "$*" >&2
  exit 1
}

require_env() {
  local name
  for name in "$@"; do
    [[ -n "${!name:-}" ]] || fail "Required variable ${name} is not set"
  done
}

manifest_value() {
  local dotted_path="$1"
  python3 - "$MANIFEST_FILE" "$dotted_path" <<'PY'
import json
import sys

path, dotted = sys.argv[1:]
with open(path, encoding="utf-8") as handle:
    value = json.load(handle)
for part in dotted.split("."):
    value = value[part]
if isinstance(value, (dict, list)):
    print(json.dumps(value, separators=(",", ":")))
else:
    print(value)
PY
}

validate_manifest() {
  python3 "${PROJECT_DIR}/scripts/validate_manifest.py" \
    --manifest "$MANIFEST_FILE" \
    --project-dir "$PROJECT_DIR" \
    --tf-root "$TF_ROOT"
}

configure_aws_oidc() {
  local role_variable="$1"
  local role_arn="${!role_variable:-}"

  require_env GITLAB_OIDC_TOKEN AWS_DEFAULT_REGION EXPECTED_AWS_ACCOUNT_ID EXPECTED_AWS_PARTITION
  [[ -n "$role_arn" ]] || fail "Required variable ${role_variable} is not set"

  umask 077
  printf '%s' "$GITLAB_OIDC_TOKEN" > "$AWS_TOKEN_FILE"
  export AWS_WEB_IDENTITY_TOKEN_FILE="$AWS_TOKEN_FILE"
  export AWS_ROLE_ARN="$role_arn"
  export AWS_ROLE_SESSION_NAME="gitlab-tf-import-${CI_PROJECT_ID:-local}-${CI_PIPELINE_ID:-manual}"
  export AWS_STS_REGIONAL_ENDPOINTS=regional
  trap 'rm -f "$AWS_TOKEN_FILE"' EXIT
}

verify_aws_target() {
  local identity account arn partition manifest_account manifest_partition manifest_region
  identity="$(aws sts get-caller-identity --output json)"
  account="$(jq -r '.Account' <<<"$identity")"
  arn="$(jq -r '.Arn' <<<"$identity")"
  partition="$(cut -d: -f2 <<<"$arn")"
  manifest_account="$(manifest_value target.account_id)"
  manifest_partition="$(manifest_value target.partition)"
  manifest_region="$(manifest_value target.region)"

  [[ "$account" == "$EXPECTED_AWS_ACCOUNT_ID" ]] || fail "OIDC role resolved to account ${account}, expected ${EXPECTED_AWS_ACCOUNT_ID}"
  [[ "$account" == "$manifest_account" ]] || fail "OIDC account ${account} does not match manifest account ${manifest_account}"
  [[ "$partition" == "$EXPECTED_AWS_PARTITION" ]] || fail "OIDC partition ${partition} does not match expected ${EXPECTED_AWS_PARTITION}"
  [[ "$partition" == "$manifest_partition" ]] || fail "OIDC partition ${partition} does not match manifest partition ${manifest_partition}"
  [[ "$AWS_DEFAULT_REGION" == "$manifest_region" ]] || fail "AWS_DEFAULT_REGION ${AWS_DEFAULT_REGION} does not match manifest Region ${manifest_region}"

  log "Verified AWS target: account=${account} partition=${partition} region=${AWS_DEFAULT_REGION}"
}

set_state_key() {
  require_env TF_STACK
  local project_slug="${CI_PROJECT_PATH_SLUG:-local-project}"
  export TF_STATE_KEY="${TF_STATE_KEY:-tfstate/${project_slug}/${TF_STACK}/terraform.tfstate}"
  [[ "$TF_STATE_KEY" == tfstate/*/terraform.tfstate ]] || fail "TF_STATE_KEY does not match the approved stable key pattern"
  [[ "$TF_STATE_KEY" == tfstate/*/"${TF_STACK}"/terraform.tfstate ]] || fail "TF_STATE_KEY does not identify the configured TF_STACK"
}

terraform_init() {
  require_env TF_STATE_BUCKET TF_STATE_REGION
  set_state_key

  local -a args
  args=(
    -backend-config="bucket=${TF_STATE_BUCKET}"
    -backend-config="key=${TF_STATE_KEY}"
    -backend-config="region=${TF_STATE_REGION}"
    -backend-config="encrypt=true"
  )
  if [[ -n "${TF_LOCK_TABLE:-}" ]]; then
    args+=(-backend-config="dynamodb_table=${TF_LOCK_TABLE}")
  fi
  if [[ -n "${TF_STATE_KMS_KEY_ID:-}" ]]; then
    args+=(-backend-config="kms_key_id=${TF_STATE_KMS_KEY_ID}")
  fi

  terraform -chdir="$TF_DIR" init -reconfigure -input=false "${args[@]}"
  [[ "$(terraform -chdir="$TF_DIR" workspace show)" == "default" ]] || fail "Only the default Terraform workspace is permitted"
}

verify_state_bucket_controls() {
  local versioning encryption public_access algorithm
  versioning="$(aws s3api get-bucket-versioning --bucket "$TF_STATE_BUCKET" --region "$TF_STATE_REGION" --output json)"
  [[ "$(jq -r '.Status // ""' <<<"$versioning")" == "Enabled" ]] || fail "State bucket versioning must be Enabled"

  encryption="$(aws s3api get-bucket-encryption --bucket "$TF_STATE_BUCKET" --region "$TF_STATE_REGION" --output json)"
  algorithm="$(jq -r '.ServerSideEncryptionConfiguration.Rules[0].ApplyServerSideEncryptionByDefault.SSEAlgorithm // ""' <<<"$encryption")"
  [[ "$algorithm" == "AES256" || "$algorithm" == "aws:kms" ]] || fail "State bucket default encryption is not configured"
  if [[ "${TF_REQUIRE_KMS_STATE:-false}" == "true" && "$algorithm" != "aws:kms" ]]; then
    fail "TF_REQUIRE_KMS_STATE=true but state bucket encryption is ${algorithm}"
  fi

  public_access="$(aws s3api get-public-access-block --bucket "$TF_STATE_BUCKET" --region "$TF_STATE_REGION" --output json)"
  jq -e '
    .PublicAccessBlockConfiguration
    | .BlockPublicAcls and .IgnorePublicAcls and .BlockPublicPolicy and .RestrictPublicBuckets
  ' <<<"$public_access" >/dev/null || fail "All four S3 Block Public Access settings must be true"

  log "Verified state bucket controls: versioning=Enabled encryption=${algorithm} public-access=blocked"
}

capture_state_metadata() {
  local output_file="$1"
  local temp_state temp_error
  temp_state="$(mktemp)"
  temp_error="$(mktemp)"

  if terraform -chdir="$TF_DIR" state pull >"$temp_state" 2>"$temp_error"; then
    python3 - "$temp_state" "$output_file" "$TF_STATE_KEY" <<'PY'
import json
import sys

state_path, output_path, state_key = sys.argv[1:]
with open(state_path, encoding="utf-8") as handle:
    state = json.load(handle)
metadata = {
    "lineage": state.get("lineage"),
    "serial": state.get("serial"),
    "state_key": state_key,
}
with open(output_path, "w", encoding="utf-8") as handle:
    json.dump(metadata, handle, indent=2, sort_keys=True)
    handle.write("\n")
PY
  elif grep -qi "No state file was found" "$temp_error"; then
    python3 - "$output_file" "$TF_STATE_KEY" <<'PY'
import json
import sys

with open(sys.argv[1], "w", encoding="utf-8") as handle:
    json.dump({"lineage": None, "serial": None, "state_key": sys.argv[2]}, handle, indent=2, sort_keys=True)
    handle.write("\n")
PY
  else
    sed 's/^/[terraform-import] /' "$temp_error" >&2
    rm -f "$temp_state" "$temp_error"
    fail "Unable to read current Terraform state metadata"
  fi

  rm -f "$temp_state" "$temp_error"
}

list_state_addresses() {
  local output_file="$1"
  if ! terraform -chdir="$TF_DIR" state list >"$output_file" 2>"${output_file}.err"; then
    if grep -qi "No state file was found" "${output_file}.err"; then
      : >"$output_file"
    else
      sed 's/^/[terraform-import] /' "${output_file}.err" >&2
      rm -f "${output_file}.err"
      fail "Unable to list current Terraform state"
    fi
  fi
  rm -f "${output_file}.err"
}

assert_addresses_absent_from_state() {
  local state_file="$1"
  local address
  while IFS= read -r address; do
    if grep -Fxq -- "$address" "$state_file"; then
      fail "Manifest address already exists in state: ${address}"
    fi
  done < <(python3 - "$MANIFEST_FILE" <<'PY'
import json
import sys
with open(sys.argv[1], encoding="utf-8") as handle:
    manifest = json.load(handle)
for resource in manifest["resources"]:
    print(resource["address"])
PY
  )
}

assert_addresses_present_in_state() {
  local state_file="$1"
  local address
  while IFS= read -r address; do
    grep -Fxq -- "$address" "$state_file" || fail "Imported address is missing from state: ${address}"
  done < <(python3 - "$MANIFEST_FILE" <<'PY'
import json
import sys
with open(sys.argv[1], encoding="utf-8") as handle:
    manifest = json.load(handle)
for resource in manifest["resources"]:
    print(resource["address"])
PY
  )
}
