#!/usr/bin/env bash

set -Eeuo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/ci-common.sh"

validate_manifest
configure_aws_oidc AWS_PLAN_ROLE_ARN
verify_aws_target
terraform_init
verify_state_bucket_controls

output_file="${ARTIFACT_DIR}/generated_resources.tf"
log_file="${ARTIFACT_DIR}/generate.log"
rm -f "$output_file"

set +e
terraform -chdir="$TF_DIR" plan \
  -generate-config-out="$output_file" \
  -input=false \
  -lock-timeout=5m \
  -no-color 2>&1 | tee "$log_file"
plan_rc=${PIPESTATUS[0]}
set -e

[[ -s "$output_file" ]] || fail "Terraform did not produce generated configuration"
if (( plan_rc != 0 )); then
  fail "Terraform configuration generation returned exit code ${plan_rc}; review the generated file and log"
fi

log "Generated configuration is ready for engineering review; nothing was applied"

