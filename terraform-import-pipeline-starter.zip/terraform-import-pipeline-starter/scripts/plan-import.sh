#!/usr/bin/env bash

set -Eeuo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/ci-common.sh"

validate_manifest
configure_aws_oidc AWS_PLAN_ROLE_ARN
verify_aws_target
terraform_init
verify_state_bucket_controls

state_addresses="${ARTIFACT_DIR}/current-state-addresses.txt"
plan_file="${ARTIFACT_DIR}/import.tfplan"
plan_json="${ARTIFACT_DIR}/import-plan.json"
plan_text="${ARTIFACT_DIR}/import-plan.txt"
plan_log="${ARTIFACT_DIR}/plan.log"
metadata="${ARTIFACT_DIR}/plan-metadata.json"

list_state_addresses "$state_addresses"
assert_addresses_absent_from_state "$state_addresses"
capture_state_metadata "$metadata"

set +e
terraform -chdir="$TF_DIR" plan \
  -out="$plan_file" \
  -detailed-exitcode \
  -input=false \
  -lock-timeout=5m \
  -no-color 2>&1 | tee "$plan_log"
plan_rc=${PIPESTATUS[0]}
set -e

if (( plan_rc == 1 )); then
  fail "Terraform plan failed"
fi
if (( plan_rc != 2 )); then
  fail "An import plan must have changes and return detailed exit code 2; received ${plan_rc}"
fi

terraform -chdir="$TF_DIR" show -json "$plan_file" > "$plan_json"
terraform -chdir="$TF_DIR" show -no-color "$plan_file" | tee "$plan_text"
python3 "${PROJECT_DIR}/scripts/check_import_plan.py" \
  --manifest "$MANIFEST_FILE" \
  --plan-json "$plan_json"

python3 - "$metadata" "$MANIFEST_FILE" "$plan_file" <<'PY'
import hashlib
import json
import os
import subprocess
import sys

metadata_path, manifest_path, plan_path = sys.argv[1:]

def digest(path: str) -> str:
    value = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()

with open(metadata_path, encoding="utf-8") as handle:
    metadata = json.load(handle)
metadata.update(
    {
        "commit_sha": os.environ.get("CI_COMMIT_SHA", "local"),
        "manifest_sha256": digest(manifest_path),
        "plan_sha256": digest(plan_path),
        "terraform_version": subprocess.check_output(["terraform", "version", "-json"], text=True),
    }
)
metadata["terraform_version"] = json.loads(metadata["terraform_version"])["terraform_version"]
with open(metadata_path, "w", encoding="utf-8") as handle:
    json.dump(metadata, handle, indent=2, sort_keys=True)
    handle.write("\n")
PY

log "Import-only plan passed policy and is ready for review"

