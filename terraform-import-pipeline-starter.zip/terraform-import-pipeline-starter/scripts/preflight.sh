#!/usr/bin/env bash

set -Eeuo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/ci-common.sh"

validate_manifest
configure_aws_oidc AWS_PLAN_ROLE_ARN
verify_aws_target
terraform_init
verify_state_bucket_controls

state_addresses="${ARTIFACT_DIR}/current-state-addresses.txt"
metadata="${ARTIFACT_DIR}/preflight-metadata.json"
list_state_addresses "$state_addresses"
assert_addresses_absent_from_state "$state_addresses"
capture_state_metadata "$metadata"

log "Preflight passed: all manifest addresses are absent from the permanent state"

