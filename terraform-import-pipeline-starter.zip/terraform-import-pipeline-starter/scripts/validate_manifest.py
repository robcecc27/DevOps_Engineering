#!/usr/bin/env python3

import argparse
import json
import os
import re
import sys
from pathlib import Path


ACCOUNT_ID = re.compile(r"^[0-9]{12}$")
PARTITIONS = {"aws", "aws-us-gov"}
ADDRESS = re.compile(r"^(?:module\.[A-Za-z0-9_-]+(?:\[[^]]+\])?\.)*[A-Za-z0-9_]+\.[A-Za-z0-9_-]+(?:\[[^]]+\])?$")


def fail(message: str) -> None:
    print(f"[terraform-import] ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--project-dir", required=True)
    parser.add_argument("--tf-root", required=True)
    args = parser.parse_args()

    manifest_path = Path(args.manifest)
    if not manifest_path.is_file():
        fail(f"Manifest does not exist: {manifest_path}")

    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        fail(f"Manifest is not valid JSON: {exc}")

    required_top = {"schema_version", "status", "change_id", "owner", "target", "resources"}
    missing = required_top - manifest.keys()
    if missing:
        fail(f"Manifest is missing keys: {', '.join(sorted(missing))}")
    if manifest["schema_version"] != 1:
        fail("schema_version must be 1")
    if manifest["status"] != "pending":
        fail("status must be pending during an import")
    if not str(manifest["change_id"]).strip() or not str(manifest["owner"]).strip():
        fail("change_id and owner must be non-empty")

    target = manifest["target"]
    target_keys = {"account_id", "partition", "region", "terraform_root", "stack"}
    if not isinstance(target, dict) or target_keys - target.keys():
        fail(f"target must contain: {', '.join(sorted(target_keys))}")
    if not ACCOUNT_ID.fullmatch(str(target["account_id"])):
        fail("target.account_id must be a 12-digit AWS account ID")
    if target["partition"] not in PARTITIONS:
        fail("target.partition must be aws or aws-us-gov")
    if target["terraform_root"] != args.tf_root:
        fail("target.terraform_root does not match TF_ROOT")
    if os.environ.get("TF_STACK") and target["stack"] != os.environ["TF_STACK"]:
        fail("target.stack does not match TF_STACK")

    expected = {
        "account_id": os.environ.get("EXPECTED_AWS_ACCOUNT_ID"),
        "partition": os.environ.get("EXPECTED_AWS_PARTITION"),
        "region": os.environ.get("AWS_DEFAULT_REGION"),
    }
    for key, value in expected.items():
        if value and target[key] != value:
            fail(f"target.{key} does not match the corresponding CI variable")

    resources = manifest["resources"]
    if not isinstance(resources, list) or not resources:
        fail("resources must be a non-empty list")
    addresses: set[str] = set()
    pairs: set[tuple[str, str]] = set()
    for index, resource in enumerate(resources):
        if not isinstance(resource, dict):
            fail(f"resources[{index}] must be an object")
        for key in ("address", "import_id", "description"):
            if not str(resource.get(key, "")).strip():
                fail(f"resources[{index}].{key} must be non-empty")
        address = resource["address"]
        import_id = resource["import_id"]
        if not ADDRESS.fullmatch(address):
            fail(f"resources[{index}].address is not a valid Terraform resource address")
        if address in addresses:
            fail(f"Duplicate resource address: {address}")
        pair = (address, import_id)
        if pair in pairs:
            fail(f"Duplicate address/import ID pair: {address}")
        addresses.add(address)
        pairs.add(pair)

    lock_file = Path(args.project_dir, args.tf_root, ".terraform.lock.hcl")
    if os.environ.get("ALLOW_MISSING_TF_LOCK", "false").lower() != "true" and not lock_file.is_file():
        fail(f"Provider lock file is required: {lock_file}")

    print(
        f"[terraform-import] Manifest valid: {len(resources)} resource(s), "
        f"account={target['account_id']} partition={target['partition']} region={target['region']}"
    )


if __name__ == "__main__":
    main()

