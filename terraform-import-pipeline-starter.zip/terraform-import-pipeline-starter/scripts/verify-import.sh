#!/usr/bin/env bash

set -Eeuo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/ci-common.sh"

validate_manifest
configure_aws_oidc AWS_PLAN_ROLE_ARN
verify_aws_target
terraform_init

post_addresses="${ARTIFACT_DIR}/post-import-addresses.txt"
list_state_addresses "$post_addresses"
assert_addresses_present_in_state "$post_addresses"

set +e
terraform -chdir="$TF_DIR" plan \
  -detailed-exitcode \
  -input=false \
  -lock-timeout=5m \
  -no-color 2>&1 | tee "${ARTIFACT_DIR}/verify.log" "${ARTIFACT_DIR}/post-import-plan.txt"
plan_rc=${PIPESTATUS[0]}
set -e

if (( plan_rc != 0 )); then
  fail "Post-import plan must be empty (exit 0); received exit code ${plan_rc}"
fi

log "Post-import verification passed with zero changes"
