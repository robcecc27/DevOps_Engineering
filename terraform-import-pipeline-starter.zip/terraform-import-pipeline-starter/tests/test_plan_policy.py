#!/usr/bin/env python3

import subprocess
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CHECKER = ROOT / "scripts" / "check_import_plan.py"
MANIFEST = ROOT / "tests" / "fixtures" / "manifest.json"


class PlanPolicyTests(unittest.TestCase):
    def run_policy(self, fixture: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [
                sys.executable,
                str(CHECKER),
                "--manifest",
                str(MANIFEST),
                "--plan-json",
                str(ROOT / "tests" / "fixtures" / fixture),
            ],
            check=False,
            capture_output=True,
            text=True,
        )

    def test_allows_exact_import_with_no_mutation(self) -> None:
        result = self.run_policy("plan-allowed.json")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("POLICY ALLOW", result.stdout)

    def test_denies_update(self) -> None:
        result = self.run_policy("plan-denied-update.json")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("forbidden actions", result.stderr)

    def test_denies_extra_import(self) -> None:
        result = self.run_policy("plan-denied-extra-import.json")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("not declared in manifest", result.stderr)


if __name__ == "__main__":
    unittest.main()
